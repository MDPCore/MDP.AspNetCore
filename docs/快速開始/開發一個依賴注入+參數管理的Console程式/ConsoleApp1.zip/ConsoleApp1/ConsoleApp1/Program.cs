﻿using System;

namespace ConsoleApp1
{
    public class Program
    {
        // Methods
        public static void Run(MessageRepository messageRepository)
        {
            // Message
            var message = messageRepository.GetValue();

            // Display
            Console.WriteLine(message);
        }

        public static void Main(string[] args)
        {
            // Host
            MDP.NetCore.Host.Run<Program>(args);
        }
    }
}
