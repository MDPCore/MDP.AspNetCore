﻿namespace WebApplication1
{
    public interface MessageRepository
    {
        // Methods
        string GetValue();
    }
}
