﻿using System;
using System.Security.Cryptography;

namespace ConsoleApp1
{
    public class Program
    {
        // Methods
        public static void Main(string[] args)
        {
            // HmacKey
            string hmacKey = string.Empty;
            using (HMACSHA256 hmac = new HMACSHA256())
            {
                hmacKey = Convert.ToBase64String(hmac.Key);
            }

            // Display
            Console.WriteLine("HMAC Key:");
            Console.WriteLine(hmacKey);
            Console.ReadLine();
        }
    }
}