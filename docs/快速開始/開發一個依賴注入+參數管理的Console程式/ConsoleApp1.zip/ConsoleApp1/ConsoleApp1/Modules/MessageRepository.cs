﻿namespace ConsoleApp1
{
    public interface MessageRepository
    {
        // Methods
        string GetValue();
    }
}
