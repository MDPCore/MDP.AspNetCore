﻿using MDP.Registration;

namespace WebApplication1
{
    [Service<MessageRepository>()]
    public class ConfigMessageRepository : MessageRepository
    {
        // Fields
        private readonly string _message;


        // Constructors
        public ConfigMessageRepository(string message)
        {
            // Default
            _message = message;
        }


        // Methods
        public string GetValue()
        {
            // Return
            return _message;
        }
    }
}
