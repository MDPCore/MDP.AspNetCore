﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1
{
    public class HomeController : Controller
    {
        // Fields
        private readonly MessageRepository _messageRepository = null;


        // Constructors
        public HomeController(MessageRepository messageRepository)
        {
            // Default
            _messageRepository = messageRepository;
        }


        // Methods
        public IndexResultModel Index()
        {
            // ResultModel
            var resultModel = new IndexResultModel();
            resultModel.Message = _messageRepository.GetValue();

            // Return
            return resultModel;
        }


        // Class
        public class IndexResultModel
        {
            // Properties
            public string Message { get; set; }
        }
    }
}
